# Tradutor de Latidos — Repositório pronto para GitHub Actions (v2)

Este repositório contém tudo o que você precisa para gerar automaticamente um APK debug do app **Tradutor de Latidos** usando GitHub Actions.

## O que foi adicionado nesta versão (v2)
- Ícones Android em todas as densidades (mipmap-*/ic_launcher.png)  
- Splash screen image (splash.png) com fundo #0e172a e ícone central  
- Som divertido `au_au.wav` que toca quando o usuário clica em **Detectar Latidos**

## Passo a passo rápido

1. Crie um repositório novo no GitHub (ex: Tradutor-de-Latidos).
2. Faça upload (arrastar) de todo o conteúdo deste ZIP.
3. No GitHub, vá em **Actions → Tradutor de Latidos Build** e clique em **Run workflow**.
4. Após a execução, abra a aba **Jobs → build → Artifacts** e baixe o APK debug (`app-debug.apk`).

## Observações
- O APK será gerado em modo **debug** (instalável manualmente no Android).
- O app já pede permissão de microfone via getUserMedia; o `AndroidManifest.xml` gerado pelo Capacitor incluirá permissões necessárias.
- Se quiser o APK assinado para Play Store, me avise e eu explico os próximos passos.

Bom teste! — Amauri
